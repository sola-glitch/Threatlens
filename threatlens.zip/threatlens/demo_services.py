"""Spin up deliberately weak FAKE services on localhost so you can try ThreatLens safely.

    python demo_services.py        # then scan 127.0.0.1 with the "custom" ports below

Ports: 2121 FTP(vsFTPd 2.3.4), 2222 SSH(OpenSSH 5.3), 6379 Redis(no auth),
       8080 HTTP(Apache/2.2.8, PHP/5.2), 8443 TLS(self-signed), 4444 silent listener.
None of these do anything real; they only print banners.
"""
import datetime
import socket
import ssl
import tempfile
import threading
import time

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

HTTP_REPLY = (b"HTTP/1.1 200 OK\r\nServer: Apache/2.2.8 (Ubuntu)\r\nX-Powered-By: PHP/5.2.4\r\n"
              b"Content-Length: 0\r\nConnection: close\r\n\r\n")


def serve(port, handler, wrap=None):
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("127.0.0.1", port))
    s.listen(32)

    def loop():
        while True:
            c, _ = s.accept()
            def one(c=c):
                try:
                    c.settimeout(2)
                    if wrap:
                        c = wrap(c)
                    handler(c)
                except Exception:
                    pass
                finally:
                    try:
                        c.close()
                    except Exception:
                        pass
            threading.Thread(target=one, daemon=True).start()
    threading.Thread(target=loop, daemon=True).start()


def make_ctx(days=-5):
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "demo.internal")])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(now - datetime.timedelta(days=400))
            .not_valid_after(now + datetime.timedelta(days=days)).sign(key, hashes.SHA256()))
    d = tempfile.mkdtemp()
    open(f"{d}/c.pem", "wb").write(cert.public_bytes(serialization.Encoding.PEM))
    open(f"{d}/k.pem", "wb").write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
                                                     serialization.NoEncryption()))
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(f"{d}/c.pem", f"{d}/k.pem")
    return ctx


def main():
    ctx = make_ctx()

    def http(c):
        c.recv(1024)
        c.sendall(HTTP_REPLY)

    serve(2121, lambda c: c.sendall(b"220 (vsFTPd 2.3.4)\r\n"))
    serve(2222, lambda c: c.sendall(b"SSH-2.0-OpenSSH_5.3\r\n"))
    serve(6379, lambda c: (c.recv(64), c.sendall(b"+PONG\r\n")))
    serve(8080, http)
    serve(8443, http, wrap=lambda c: ctx.wrap_socket(c, server_side=True))
    serve(4444, lambda c: time.sleep(1))
    print("Demo services running. Scan 127.0.0.1 with ports: 2121,2222,6379,8080,8443,4444   (Ctrl+C to stop)")
    while True:
        time.sleep(3600)


if __name__ == "__main__":
    main()
