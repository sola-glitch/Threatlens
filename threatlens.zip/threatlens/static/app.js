"use strict";
// All untrusted data (banners, cert names, hostnames) is inserted with textContent, never innerHTML.
const $ = (id) => document.getElementById(id);
const SEV_COLOR = { info: "var(--info)", low: "var(--low)", medium: "var(--medium)", high: "var(--high)", critical: "var(--critical)" };
const GRADE_COLOR = { Minimal: "var(--accent)", Low: "var(--accent)", Moderate: "var(--medium)", High: "var(--high)", Critical: "var(--critical)" };
let currentId = null, pollTimer = null;

function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === "class") el.className = v;
    else if (k === "style") el.style.cssText = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v);
  }
  for (const kid of kids.flat()) if (kid != null) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  return el;
}
const fmtTime = (t) => new Date(t * 1000).toLocaleString([], { dateStyle: "short", timeStyle: "short" });
const sevOf = (w) => (w >= 9 ? "critical" : w >= 7 ? "high" : w >= 4 ? "medium" : w >= 2 ? "low" : "info");

async function api(path, opts) {
  const r = await fetch(path, opts);
  let data = {};
  try { data = await r.json(); } catch (_) {}
  if (!r.ok) throw new Error(data.error || `Request failed (${r.status})`);
  return data;
}

function drawGauge(score, color) {
  const len = Math.PI * 80, filled = (score / 100) * len;
  $("gauge").replaceChildren();
  const ns = "http://www.w3.org/2000/svg";
  const mk = (stroke, dash) => {
    const p = document.createElementNS(ns, "path");
    p.setAttribute("d", "M10 95 A80 80 0 0 1 170 95");
    p.setAttribute("fill", "none"); p.setAttribute("stroke", stroke);
    p.setAttribute("stroke-width", "14"); p.setAttribute("stroke-linecap", "round");
    if (dash) p.setAttribute("stroke-dasharray", dash);
    return p;
  };
  $("gauge").append(mk("var(--panel2)"), mk(color, `${filled} ${len}`));
}

function render(d) {
  $("empty").classList.add("hidden");
  $("report").classList.remove("hidden");
  const a = d.analysis, running = d.status === "queued" || d.status === "running";
  const score = a ? a.score : 0, grade = a ? a.grade : "…";
  const color = GRADE_COLOR[grade] || "var(--muted)";
  drawGauge(score, color);
  $("scoreNum").textContent = a ? score.toFixed(0) : "…";
  $("grade").textContent = running ? "scanning" : grade;
  $("grade").style.color = color;
  $("mTarget").textContent = d.target + (d.ip !== d.target ? ` (${d.ip})` : "");
  $("mScope").textContent = d.scope;
  const dur = d.duration ? ` in ${d.duration}s` : "";
  $("mSub").textContent = `${d.options.total_ports} ports · ${d.open_count} open · ${d.closed} closed · ${d.filtered} filtered${dur}` +
    (d.status === "cancelled" ? " · cancelled" : "") + (d.error ? ` · error: ${d.error}` : "");
  const pct = d.progress.total ? Math.round((d.progress.done / d.progress.total) * 100) : 0;
  $("progressWrap").classList.toggle("hidden", !running);
  $("progressTxt").textContent = running ? `${d.progress.done}/${d.progress.total} ports probed (${pct}%)` : "";
  $("bar").style.width = pct + "%";
  $("cancelBtn").classList.toggle("hidden", !running);
  for (const [id, ext] of [["expJson", "json"], ["expCsv", "csv"]]) {
    $(id).classList.toggle("hidden", running);
    $(id).href = `/api/scans/${d.id}/export.${ext}`;
  }
  $("sevChips").replaceChildren(...(a ? ["critical", "high", "medium", "low", "info"].filter((s) => a.severity_counts[s])
    .map((s) => h("span", { class: "chip", style: `color:${SEV_COLOR[s]};border-color:${SEV_COLOR[s]}` }, `${a.severity_counts[s]} ${s}`)) : []));

  // diff vs previous scan
  const diff = d.diff, box = $("diffBox");
  box.classList.toggle("hidden", !diff);
  if (diff) {
    const parts = [h("b", {}, "Since last scan "), h("span", { class: "muted" }, `(${fmtTime(diff.previous_started)}): `)];
    if (!diff.port_set_changed) parts.push("no change in open ports. ");
    if (diff.newly_open.length) parts.push(h("b", { class: "new" }, `newly open: ${diff.newly_open.join(", ")}. `));
    if (diff.newly_closed.length) parts.push(h("b", { class: "gone" }, `closed: ${diff.newly_closed.join(", ")}. `));
    parts.push(`Score ${diff.score_delta > 0 ? "+" : ""}${diff.score_delta}.`);
    box.replaceChildren(...parts);
  }

  // top actions
  $("topBox").classList.toggle("hidden", !(a && a.top_actions.length));
  $("topList").replaceChildren(...(a ? a.top_actions.map((t) =>
    h("li", {}, h("span", { class: `sev sev-${t.severity}` }, t.severity), " ", t.title, h("small", {}, t.fix))) : []));

  // ports table
  const wByPort = {};
  if (a) for (const f of a.findings) if (f.port != null) wByPort[f.port] = (wByPort[f.port] || 0) + f.weight;
  $("openCount").textContent = `(${d.open_count})`;
  $("portTable").querySelector("tbody").replaceChildren(...d.results.map((r) => {
    const w = wByPort[r.port] || 0, sev = sevOf(w);
    const bn = h("td", { class: "banner" }, r.banner || (r.tls_error ? "TLS handshake failed" : "no banner"));
    if (r.tls) bn.append(h("span", { class: "tls" }, `${r.tls.version || "TLS"} · ${r.tls.cipher || ""}` +
      (r.tls.subject ? ` · ${r.tls.subject}` : "") + (r.tls.days_left != null ? ` · expires in ${r.tls.days_left}d` : "")));
    return h("tr", {},
      h("td", { class: "port" }, r.port),
      h("td", {}, r.label || r.service || "…"),
      h("td", {}, h("span", { class: "riskbar" }, h("i", { style: `width:${Math.min(100, w * 8)}%;background:${SEV_COLOR[sev]}` })),
        h("span", { class: `sev sev-${sev}` }, sev)),
      bn, h("td", { class: "muted" }, r.rtt_ms));
  }));

  // findings
  $("findCount").textContent = a ? `(${a.findings.length})` : "";
  $("findings").replaceChildren(...(a ? a.findings.map((f) => h("div", { class: `finding f-${f.severity}` },
    h("h3", {}, h("span", { class: `sev sev-${f.severity}` }, f.severity), f.title, h("span", { class: "w" }, `+${f.weight}`)),
    h("p", {}, f.detail), h("p", { class: "fix" }, "Fix: " + f.remediation))) : []));
  if (a && !a.findings.length) $("findings").append(h("p", { class: "muted" }, "No open ports found. Nothing to report."));

  // categories
  const cats = a ? Object.entries(a.categories).sort((x, y) => y[1] - x[1]) : [], max = cats.length ? cats[0][1] : 1;
  $("catCard").classList.toggle("hidden", !cats.length);
  $("cats").replaceChildren(...cats.map(([n, v]) => h("div", { class: "cat" }, h("span", {}, n),
    h("div", { class: "b" }, h("i", { style: `width:${(v / max) * 100}%` })), h("span", {}, v.toFixed(1)))));
}

async function poll(id) {
  clearTimeout(pollTimer);
  if (id !== currentId) return;
  try {
    const d = await api(`/api/scans/${id}`);
    if (id !== currentId) return;
    render(d);
    if (d.status === "queued" || d.status === "running") pollTimer = setTimeout(() => poll(id), 400);
    else { $("startBtn").disabled = false; loadHistory(); }
  } catch (e) {
    $("formError").textContent = e.message; $("startBtn").disabled = false;
  }
}

function openScan(id) { currentId = id; poll(id); highlight(); }

async function loadHistory() {
  const rows = await api("/api/scans").catch(() => []);
  $("history").replaceChildren(...rows.map((r) => {
    const col = GRADE_COLOR[r.grade] || "var(--muted)";
    return h("li", { "data-id": r.id, class: r.id === currentId ? "sel" : "", onclick: () => openScan(r.id) },
      h("span", { class: "score", style: `background:${col};color:#06130e` }, r.score != null ? Math.round(r.score) : "–"),
      h("div", { class: "t" }, h("b", {}, r.target), h("small", {}, `${fmtTime(r.started)} · ${r.open_count} open · ${r.status}`)),
      h("button", { class: "del", title: "Delete", onclick: async (e) => {
        e.stopPropagation();
        await api(`/api/scans/${r.id}`, { method: "DELETE" }).catch(() => {});
        if (currentId === r.id) { currentId = null; $("report").classList.add("hidden"); $("empty").classList.remove("hidden"); }
        loadHistory();
      } }, "✕"));
  }));
}
function highlight() { document.querySelectorAll("#history li").forEach((li) => li.classList.toggle("sel", li.dataset.id === currentId)); }

$("preset").addEventListener("change", () => $("customPorts").classList.toggle("hidden", $("preset").value !== "custom"));
$("refreshHist").addEventListener("click", loadHistory);
$("cancelBtn").addEventListener("click", () => currentId && api(`/api/scans/${currentId}/cancel`, { method: "POST" }).catch(() => {}));

$("scanForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("formError").textContent = "";
  const preset = $("preset").value;
  const body = {
    target: $("target").value, ports: preset === "custom" ? $("customPorts").value : preset,
    timeout: parseFloat($("timeout").value), workers: parseInt($("workers").value, 10), authorized: $("authorized").checked,
  };
  $("startBtn").disabled = true;
  try {
    const d = await api("/api/scans", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    openScan(d.id);
  } catch (err) {
    $("formError").textContent = err.message; $("startBtn").disabled = false;
  }
});

(async () => {
  const cfg = await api("/api/config").catch(() => ({}));
  $("scopeNote").textContent = cfg.allow_public ? "Public targets enabled: scan only systems you own." : "Scope: loopback & private networks only";
  loadHistory();
})();
