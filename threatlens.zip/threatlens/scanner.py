"""TCP connect scanner with banner grabbing, light fingerprinting and TLS inspection.

Uses plain full-connect scans (no raw sockets, no root needed). The only
application-layer probes sent are harmless read-only ones: HEAD/GET for web
ports, PING for Redis, `version` for memcached.
"""
from __future__ import annotations

import errno
import re
import socket
import ssl
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone

try:  # optional: richer certificate details
    from cryptography import x509
except Exception:  # pragma: no cover
    x509 = None

TLS_PORTS = {443, 465, 636, 993, 995, 2376, 6443, 8443, 9443, 10250}
HTTP_PORTS = {80, 443, 3000, 5000, 5601, 5984, 8000, 8008, 8080, 8081, 8088, 8443, 8888, 9000, 9090, 9200, 9443, 15672}
HTTP_PROBE = b"HEAD / HTTP/1.0\r\nHost: localhost\r\nUser-Agent: ThreatLens/1.0\r\nConnection: close\r\n\r\n"
SPECIAL_PROBES = {
    6379: b"PING\r\n",
    11211: b"version\r\n",
    9200: b"GET / HTTP/1.0\r\nHost: localhost\r\nUser-Agent: ThreatLens/1.0\r\n\r\n",
    2375: b"GET /version HTTP/1.0\r\nHost: localhost\r\nUser-Agent: ThreatLens/1.0\r\n\r\n",
}
COMMON_PORTS = sorted({21, 22, 23, 25, 53, 69, 80, 110, 111, 119, 123, 135, 137, 139, 143, 161, 179, 389, 443, 445, 465,
                       512, 513, 514, 515, 548, 587, 631, 636, 873, 993, 995, 1080, 1433, 1521, 1723, 2049, 2375, 2376,
                       3000, 3306, 3389, 4444, 5000, 5432, 5601, 5900, 5984, 6379, 6443, 7001, 8000, 8080, 8081, 8443,
                       8888, 9000, 9090, 9200, 9300, 10250, 11211, 15672, 27017})
MAX_BANNER = 400


def parse_ports(spec: str, max_ports: int = 5000) -> list[int]:
    """Parse '22,80,8000-8100' or presets 'common' / 'top1024' / 'all-low'."""
    spec = (spec or "").strip().lower()
    if spec in ("", "common"):
        return list(COMMON_PORTS)
    if spec in ("top1024", "well-known"):
        return list(range(1, 1025))
    ports: set[int] = set()
    for part in spec.replace(" ", "").split(","):
        if not part:
            continue
        if re.fullmatch(r"\d{1,5}-\d{1,5}", part):
            a, b = (int(x) for x in part.split("-"))
            if a > b:
                a, b = b, a
            ports.update(range(a, b + 1))
        elif re.fullmatch(r"\d{1,5}", part):
            ports.add(int(part))
        else:
            raise ValueError(f"Invalid port expression: {part!r}")
        if len(ports) > max_ports:
            raise ValueError(f"Too many ports (limit {max_ports})")
    bad = [p for p in ports if not 1 <= p <= 65535]
    if bad:
        raise ValueError("Ports must be between 1 and 65535")
    if not ports:
        raise ValueError("No ports specified")
    return sorted(ports)


def _clean(raw: bytes) -> str:
    text = raw.decode("utf-8", "replace")
    text = re.sub(r"[^\x20-\x7e¡-￿]+", " ", text).strip()
    return text[:MAX_BANNER]


def _recv(sock, n=2048) -> bytes:
    try:
        return sock.recv(n)
    except (socket.timeout, ssl.SSLError, OSError):
        return b""


def _recv_all(sock, limit=4096, deadline=1.5) -> bytes:
    end = time.monotonic() + deadline
    buf = b""
    while len(buf) < limit and time.monotonic() < end:
        chunk = _recv(sock, 1024)
        if not chunk:
            break
        buf += chunk
    return buf


def _tls_details(ssock) -> dict:
    info = {"version": ssock.version(), "cipher": (ssock.cipher() or ("", "", 0))[0]}
    if x509 is not None:
        try:
            cert = x509.load_der_x509_certificate(ssock.getpeercert(binary_form=True))
            not_after = getattr(cert, "not_valid_after_utc", None) or cert.not_valid_after.replace(tzinfo=timezone.utc)
            subj, issuer = cert.subject.rfc4514_string(), cert.issuer.rfc4514_string()
            days = (not_after - datetime.now(timezone.utc)).days
            info.update(subject=subj[:200], issuer=issuer[:200], not_after=not_after.isoformat(),
                        days_left=days, self_signed=subj == issuer, expired=days < 0)
        except Exception:
            pass
    return info


def _parse_http(text: str) -> dict:
    out = {}
    first = text.split("\r\n", 1)[0].split("\n", 1)[0]
    m = re.match(r"HTTP/\d\.\d (\d{3})", first)
    if m:
        out["status"] = int(m.group(1))
    for h in ("Server", "X-Powered-By"):
        m = re.search(rf"^{h}:\s*(.+)$", text, re.I | re.M)
        if m:
            out[h.lower().replace("-", "_")] = m.group(1).strip()[:120]
    return out


def identify(port: int, raw: bytes, text: str) -> str | None:
    """Guess the service from what it said, independent of port number."""
    t = text
    if t.startswith("SSH-"):
        return "ssh"
    if t.startswith("RFB "):
        return "vnc"
    if t.startswith("+PONG") or t.startswith("-NOAUTH") or t.startswith("-ERR unknown command"):
        return "redis"
    if t.startswith("VERSION ") and port == 11211:
        return "memcached"
    if len(raw) > 6 and raw[4] == 0x0A and b"\x00" in raw[5:] and re.match(rb"\d+\.\d+", raw[5:12] or b""):
        return "mysql"
    if t.startswith("HTTP/"):
        if port == 2375:
            return "docker"
        if port == 9200:
            return "elasticsearch"
        return None  # keep port-based http classification
    if re.match(r"220[ -].*\b(FTP|vsFTPd|ProFTPD|Pure-FTPd|FileZilla)", t, re.I):
        return "ftp"
    if re.match(r"220[ -].*\b(SMTP|ESMTP|Postfix|Exim|Sendmail)", t, re.I):
        return "smtp"
    if t.startswith("+OK"):
        return "pop3"
    if t.startswith("* OK"):
        return "imap"
    return None


def probe_port(host: str, family: int, port: int, timeout: float, grab: bool = True) -> dict:
    """Return {'port', 'state', ...}. state ∈ open|closed|filtered."""
    s = socket.socket(family, socket.SOCK_STREAM)
    s.settimeout(timeout)
    t0 = time.perf_counter()
    try:
        s.connect((host, port))
    except socket.timeout:
        s.close()
        return {"port": port, "state": "filtered"}
    except ConnectionRefusedError:
        s.close()
        return {"port": port, "state": "closed"}
    except OSError as e:
        s.close()
        state = "filtered" if e.errno in (errno.EHOSTUNREACH, errno.ENETUNREACH, errno.ETIMEDOUT, errno.EACCES) else "closed"
        return {"port": port, "state": state}

    res = {"port": port, "state": "open", "rtt_ms": round((time.perf_counter() - t0) * 1000, 2),
           "banner": "", "flags": []}
    if not grab:
        s.close()
        return res

    raw = b""
    try:
        io = s
        tls = None
        if port in TLS_PORTS:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            s.settimeout(max(timeout, 1.5))
            try:
                io = ctx.wrap_socket(s)
                tls = _tls_details(io)
                res["tls"] = tls
                v = tls.get("version") or ""
                if v in ("TLSv1", "TLSv1.1", "SSLv3"):
                    res["flags"].append("tls_legacy")
                if tls.get("expired"):
                    res["flags"].append("tls_expired")
                elif tls.get("days_left", 999) <= 30:
                    res["flags"].append("tls_expiring")
                if tls.get("self_signed"):
                    res["flags"].append("tls_self_signed")
            except (ssl.SSLError, OSError):
                io = None
                res["tls_error"] = True
        if io is not None:
            io.settimeout(min(max(timeout, 0.5) + 0.5, 2.0))
            probe = SPECIAL_PROBES.get(port) or (HTTP_PROBE if port in HTTP_PORTS else None)
            if probe is None:
                io.settimeout(0.6)
                raw = _recv(io)  # server-speaks-first protocols (SSH, FTP, SMTP, MySQL...)
            else:
                io.settimeout(min(max(timeout, 0.5) + 0.5, 2.0))
                try:
                    io.sendall(probe)
                    raw = _recv_all(io)
                except OSError:
                    pass
    finally:
        try:
            s.close()
        except OSError:
            pass

    text = _clean(raw)
    hdr = raw.split(b"\r\n\r\n", 1)[0].decode("utf-8", "replace") if raw.startswith(b"HTTP/") else ""
    if hdr:
        http = _parse_http(hdr)
        res["http"] = http
        bits = [f"HTTP {http.get('status', '?')}"]
        if "server" in http:
            bits.append(f"Server: {http['server']}")
        if "x_powered_by" in http:
            bits.append(f"X-Powered-By: {http['x_powered_by']}")
        res["banner"] = _clean(" | ".join(bits).encode())
    elif len(raw) > 6 and raw[4] == 0x0A and re.match(rb"\d+\.\d+", raw[5:12] or b""):
        res["banner"] = "MySQL " + raw[5:].split(b"\x00")[0].decode("ascii", "replace")
    else:
        res["banner"] = text

    svc = identify(port, raw, text)
    if svc:
        res["service"] = svc
    body = raw.split(b"\r\n\r\n", 1)[1].decode("utf-8", "replace") if b"\r\n\r\n" in raw else ""
    if text.startswith("+PONG"):
        res["flags"].append("redis_unauthenticated")
    if port == 11211 and text.startswith("VERSION "):
        res["flags"].append("memcached_open")
    if port == 2375 and '"ApiVersion"' in body:
        res["flags"].append("docker_api_unauth")
    if port == 9200 and res.get("http", {}).get("status") == 200 and "cluster_name" in body:
        res["flags"].append("es_unauth")
    return res


def run_scan(host: str, family: int, ports: list[int], timeout: float = 0.8, workers: int = 100,
             cancel: threading.Event | None = None, on_progress=None, on_open=None) -> dict:
    """Scan `ports`; returns {'open': [...], 'closed': n, 'filtered': n, 'cancelled': bool}."""
    cancel = cancel or threading.Event()
    opened, closed, filtered, done = [], 0, 0, 0
    lock = threading.Lock()

    def task(p):
        if cancel.is_set():
            return None
        return probe_port(host, family, p, timeout)

    with ThreadPoolExecutor(max_workers=max(1, min(workers, 500))) as ex:
        futures = [ex.submit(task, p) for p in ports]
        for fut in as_completed(futures):
            r = fut.result()
            with lock:
                done += 1
                if r is not None:
                    if r["state"] == "open":
                        opened.append(r)
                        if on_open:
                            on_open(r)
                    elif r["state"] == "closed":
                        closed += 1
                    else:
                        filtered += 1
            if on_progress:
                on_progress(done, len(ports))
    opened.sort(key=lambda r: r["port"])
    return {"open": opened, "closed": closed, "filtered": filtered, "cancelled": cancel.is_set()}
