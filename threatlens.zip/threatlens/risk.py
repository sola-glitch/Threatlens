"""ThreatLens weighted risk model.

Every open port becomes one or more *findings*, each with a weight (0-12).
Weights are summed, scaled by how exposed the target is (loopback < private
< public) and squashed onto 0-100 with a saturating curve so that one critical
issue is clearly bad but ten issues cannot overflow the scale.
"""
from __future__ import annotations

import math
import re

SEVERITIES = ["info", "low", "medium", "high", "critical"]

SCOPE_MULTIPLIER = {"loopback": 0.6, "private": 0.85, "public": 1.0}

SERVICES: dict[str, dict] = {}
PORT_MAP: dict[int, str] = {}


def _add(key, label, weight, category, why, fix, clear=0.0, ports=()):
    SERVICES[key] = dict(key=key, label=label, weight=weight, category=category,
                         why=why, fix=fix, clear=clear)
    for p in ports:
        PORT_MAP[p] = key


# key, label, weight, category, why it matters, remediation, cleartext penalty, ports
_add("ftp", "FTP", 6, "File transfer", "FTP sends credentials and data in cleartext and has a long history of server bugs.",
     "Replace with SFTP/FTPS, or restrict to a management network.", 2, (21,))
_add("ssh", "SSH", 3, "Remote access", "Remote shell access is a prime brute-force and credential-stuffing target.",
     "Use key-only auth, disable root login, restrict source IPs, run fail2ban.", 0, (22,))
_add("telnet", "Telnet", 9, "Remote access", "Telnet is unencrypted remote administration; anyone on path can read passwords.",
     "Disable Telnet and use SSH.", 3, (23,))
_add("smtp", "SMTP", 3, "Mail", "Open mail relays and verbose SMTP banners enable spam relay and user enumeration.",
     "Require auth/TLS, disable open relay, restrict to mail hosts.", 0, (25,))
_add("dns", "DNS", 3, "Infrastructure", "DNS over TCP can expose zone transfers and amplification vectors.",
     "Restrict zone transfers; limit recursion to trusted clients.", 0, (53,))
_add("tftp", "TFTP", 7, "File transfer", "TFTP has no authentication at all.",
     "Disable TFTP or isolate it on a provisioning VLAN.", 2, (69,))
_add("http", "HTTP", 2, "Web", "Unencrypted web traffic can be intercepted or modified in transit.",
     "Redirect to HTTPS and enable HSTS.", 0.5, (80,))
_add("pop3", "POP3", 5, "Mail", "POP3 transmits mailbox credentials in cleartext.",
     "Use POP3S (995) or retire in favour of IMAPS.", 2, (110,))
_add("rpcbind", "RPC portmapper", 7, "Infrastructure", "rpcbind reveals RPC services and is abused for amplification and recon.",
     "Block at the firewall; disable if NFS/NIS aren't needed.", 0, (111,))
_add("nntp", "NNTP", 3, "Mail", "Legacy news protocol rarely needed on modern hosts.", "Disable if unused.", 1, (119,))
_add("ntp", "NTP", 2, "Infrastructure", "Misconfigured NTP can be used for reflection attacks.",
     "Disable monlist/query, restrict to trusted clients.", 0, (123,))
_add("msrpc", "MS-RPC", 7, "Windows", "MS-RPC endpoint mapper exposes Windows internals and has many historic RCE bugs.",
     "Block 135 at the perimeter and between segments.", 0, (135,))
_add("netbios", "NetBIOS", 6, "Windows", "NetBIOS leaks host/share names and enables legacy SMB attacks.",
     "Disable NetBIOS over TCP/IP; block 137-139.", 0, (137, 138, 139))
_add("imap", "IMAP", 4, "Mail", "Cleartext IMAP exposes credentials and mail content.",
     "Enforce IMAPS (993) or STARTTLS.", 2, (143,))
_add("snmp", "SNMP", 5, "Infrastructure", "SNMP with default community strings leaks full device config.",
     "Use SNMPv3, change communities, restrict sources.", 0, (161,))
_add("bgp", "BGP", 4, "Infrastructure", "Exposed BGP sessions risk route hijack and session reset attacks.",
     "Restrict to peer addresses with ACLs / MD5 / TCP-AO.", 0, (179,))
_add("ldap", "LDAP", 5, "Directory", "Cleartext LDAP exposes directory data and binds.",
     "Use LDAPS / StartTLS and require signing.", 2, (389,))
_add("https", "HTTPS", 1, "Web", "Public web surface; risk depends on the application behind it.",
     "Keep TLS and the web stack patched.", 0, (443,))
_add("smb", "SMB", 8, "Windows", "SMB is the vector for EternalBlue, ransomware spread and credential relay.",
     "Block 445 from untrusted networks; disable SMBv1; require signing.", 0, (445,))
_add("smtps", "SMTPS", 1, "Mail", "Encrypted SMTP submission.", "Keep TLS current.", 0, (465, 587))
_add("rexec", "r-services (rexec/rlogin/rsh)", 9, "Remote access", "Legacy r-services use host-based trust and no encryption.",
     "Disable entirely; use SSH.", 3, (512, 513, 514))
_add("lpd", "LPD printing", 5, "Infrastructure", "Legacy print daemons have a record of RCE and info leaks.",
     "Disable or restrict to print VLAN.", 0, (515,))
_add("afp", "AFP", 5, "File transfer", "Apple Filing Protocol exposure risks credential attacks.", "Migrate to SMB with signing; restrict access.", 0, (548,))
_add("ipp", "IPP printing", 3, "Infrastructure", "Print services can leak info and have had RCE bugs (CUPS).", "Restrict to trusted hosts.", 0, (631,))
_add("ldaps", "LDAPS", 2, "Directory", "Directory service exposed over TLS.", "Restrict to application servers.", 0, (636,))
_add("rsync", "rsync", 6, "File transfer", "rsync daemons often allow anonymous module listing and reads.",
     "Require auth, restrict modules, tunnel via SSH.", 1, (873,))
_add("imaps", "IMAPS/POP3S", 1, "Mail", "Encrypted mailbox access.", "Keep TLS current.", 0, (993, 995))
_add("socks", "SOCKS proxy", 5, "Proxy", "Open proxies are abused to pivot and anonymise attacks.", "Require auth; restrict sources.", 0, (1080,))
_add("mssql", "Microsoft SQL Server", 8, "Database", "Databases should never face untrusted networks; SA brute force and RCE are common.",
     "Bind to localhost/private network, firewall 1433.", 0, (1433,))
_add("oracle", "Oracle DB listener", 8, "Database", "TNS listener exposure enables enumeration and attack chains.",
     "Restrict listener to app servers; set listener password/ACL.", 0, (1521,))
_add("pptp", "PPTP VPN", 5, "VPN", "PPTP is cryptographically broken.", "Migrate to WireGuard/IPsec/OpenVPN.", 0, (1723,))
_add("nfs", "NFS", 7, "File transfer", "NFS exports are frequently world-readable and rely on host trust.",
     "Restrict exports; use NFSv4 with Kerberos; firewall 2049.", 0, (2049,))
_add("docker", "Docker API (plain)", 8, "Containers", "The unencrypted Docker API grants root on the host to anyone who can reach it.",
     "Never expose 2375; use the Unix socket or mutual-TLS on 2376.", 0, (2375,))
_add("docker-tls", "Docker API (TLS)", 6, "Containers", "Docker API exposed; safe only with strict client-cert auth.",
     "Verify client certs are enforced; restrict by firewall.", 0, (2376,))
_add("mysql", "MySQL / MariaDB", 8, "Database", "Databases exposed to the network invite brute force and exploitation.",
     "Bind to 127.0.0.1 or private subnet; firewall 3306.", 0, (3306,))
_add("rdp", "RDP", 8, "Remote access", "RDP is a top ransomware entry point (BlueKeep, credential stuffing).",
     "Put behind VPN/RD Gateway, enforce NLA and MFA.", 0, (3389,))
_add("backdoor", "Suspicious listener", 8, "Suspicious", "Port 4444 is the default for Metasploit handlers and many reverse shells.",
     "Investigate the listening process immediately.", 0, (4444, 31337, 12345))
_add("postgres", "PostgreSQL", 8, "Database", "Exposed PostgreSQL invites brute force and exploitation.",
     "Set listen_addresses to private; tighten pg_hba.conf.", 0, (5432,))
_add("vnc", "VNC", 8, "Remote access", "VNC is weakly authenticated and often unencrypted.",
     "Tunnel over SSH/VPN; require strong passwords.", 2, (5900, 5901, 5902))
_add("couchdb", "CouchDB", 7, "Database", "CouchDB admin party mode and RCE history.", "Require auth; bind privately.", 0, (5984,))
_add("redis", "Redis", 8, "Database", "Redis without auth/ACL allows data theft and often RCE via config writes.",
     "Bind to localhost, set requirepass/ACLs, enable protected-mode.", 0, (6379,))
_add("k8s-api", "Kubernetes API", 6, "Containers", "Cluster control plane reachable from the network.", "Restrict by CIDR; disable anonymous auth.", 0, (6443,))
_add("kubelet", "Kubelet API", 8, "Containers", "Kubelet API can execute commands in pods if anonymous auth is on.", "Disable anonymous auth; firewall 10250.", 0, (10250,))
_add("weblogic", "WebLogic admin", 6, "Web", "WebLogic consoles are targeted by frequent deserialization RCEs.", "Restrict admin ports; patch.", 0, (7001, 7002))
_add("http-alt", "Alternate HTTP", 3, "Web", "Development or admin web interface on a non-standard port, often with weaker hardening.",
     "Confirm it should be exposed; add auth and TLS.", 0.5, (3000, 5000, 8000, 8008, 8080, 8081, 8088, 8888, 9000))
_add("https-alt", "Alternate HTTPS", 2, "Web", "Non-standard HTTPS service, frequently an admin console.", "Confirm exposure is intended.", 0, (8443, 9443))
_add("prometheus", "Prometheus / Cockpit", 4, "Monitoring", "Monitoring UIs leak topology and metrics.", "Add auth; restrict to ops network.", 0, (9090,))
_add("kibana", "Kibana", 5, "Monitoring", "Kibana often has no auth and exposes log data.", "Enable security; place behind a proxy.", 0, (5601,))
_add("elasticsearch", "Elasticsearch", 8, "Database", "Elasticsearch without auth has caused many mass data leaks.", "Enable security, bind privately.", 0, (9200,))
_add("es-transport", "Elasticsearch transport", 6, "Database", "Cluster transport port exposed.", "Firewall 9300 to cluster nodes only.", 0, (9300,))
_add("memcached", "Memcached", 8, "Database", "Memcached is unauthenticated by design; abused for data theft and DDoS reflection.",
     "Bind to localhost; disable UDP; firewall 11211.", 0, (11211,))
_add("rabbitmq", "RabbitMQ management", 5, "Monitoring", "Management UI with default guest credentials is common.", "Change defaults; restrict access.", 0, (15672,))
_add("mongodb", "MongoDB", 8, "Database", "Unauthenticated MongoDB has been the root of many ransom and leak incidents.",
     "Enable auth, bind privately, firewall 27017.", 0, (27017, 27018))
_add("unknown", "Unrecognised service", 1.5, "Unknown", "An unidentified listener increases attack surface and may be unintended.",
     "Identify the owning process; close it if unneeded.", 0, ())

# (regex, id, title, weight, detail, fix)
BANNER_SIGNATURES = [
    (r"vsFTPd 2\.3\.4", "vsftpd-backdoor", "vsftpd 2.3.4 (known backdoored release)", 11,
     "This exact release shipped with a smiley-face backdoor granting a root shell.", "Replace the binary; verify package integrity."),
    (r"OpenSSH[_-]([1-6])\.", "old-openssh", "Outdated OpenSSH (pre-7.0)", 5,
     "Very old OpenSSH releases have multiple published vulnerabilities and weak defaults.", "Upgrade OpenSSH."),
    (r"Apache/2\.[0-2]\.", "old-apache", "End-of-life Apache httpd (2.0-2.2)", 5,
     "Apache 2.2 and earlier no longer receive security fixes.", "Upgrade to a supported 2.4.x release."),
    (r"Microsoft-IIS/([1-6])\.", "old-iis", "End-of-life Microsoft IIS (<=6.0)", 6,
     "IIS 6 and earlier are unsupported and have wormable flaws.", "Upgrade Windows Server / IIS."),
    (r"ProFTPD 1\.3\.[0-3]\b", "old-proftpd", "Outdated ProFTPD (1.3.0-1.3.3)", 5,
     "Contains known remote code execution vulnerabilities.", "Upgrade ProFTPD."),
    (r"nginx/(0\.|1\.[0-9]\.)", "old-nginx", "Very old nginx release", 4,
     "nginx versions this old miss years of security fixes.", "Upgrade nginx."),
    (r"OpenSSL/(0\.9|1\.0\.[01])", "old-openssl", "Outdated OpenSSL (Heartbleed-era)", 6,
     "Versions in this range are affected by Heartbleed and other critical bugs.", "Upgrade OpenSSL and rotate keys."),
    (r"PHP/([1-5]\.)", "old-php", "End-of-life PHP (5.x or older)", 5,
     "PHP 5 and earlier are unsupported.", "Upgrade to a supported PHP release."),
    (r"MySQL 5\.[0-5]\.", "old-mysql", "End-of-life MySQL (<=5.5)", 4,
     "Unsupported MySQL series.", "Upgrade to a supported release."),
    (r"Microsoft FTP Service|Pure-FTPd", None, None, 0, "", ""),
]
_VERSION_DISCLOSURE = re.compile(r"(Server|X-Powered-By):\s*[^|]*\d+\.\d+", re.I)

FLAG_FINDINGS = {
    "redis_unauthenticated": (10, "Redis accepts commands without authentication",
                              "The server replied +PONG to an unauthenticated PING. Attackers can read/write all data and often gain code execution.",
                              "Set requirepass/ACLs and bind to localhost immediately."),
    "memcached_open": (3, "Memcached answers unauthenticated commands",
                       "A 'version' command was answered without credentials.", "Bind to localhost; firewall the port."),
    "docker_api_unauth": (5, "Docker API reachable without authentication",
                          "GET /version succeeded. Anyone able to reach this port can start privileged containers and own the host.",
                          "Close the port; use mutual TLS or the Unix socket."),
    "es_unauth": (3, "Elasticsearch answers without authentication",
                  "GET / returned cluster metadata anonymously.", "Enable security features and bind privately."),
    "tls_expired": (4, "TLS certificate has expired", "Clients will reject or users will click through warnings.", "Renew the certificate."),
    "tls_expiring": (1.5, "TLS certificate expires within 30 days", "Impending outage and trust warnings.", "Renew and automate renewal."),
    "tls_self_signed": (1.5, "Self-signed TLS certificate", "Clients cannot verify identity; encourages ignoring warnings.", "Use a certificate from a trusted CA."),
    "tls_legacy": (4, "Legacy TLS protocol negotiated", "TLS 1.1 or older is deprecated and vulnerable to downgrade attacks.", "Require TLS 1.2+."),
    "http_version_disclosure": (1, "Server discloses software version", "Version banners help attackers pick exploits.", "Hide version tokens (ServerTokens Prod / server_tokens off)."),
}


def sev_for(weight: float) -> str:
    if weight >= 9:
        return "critical"
    if weight >= 7:
        return "high"
    if weight >= 4:
        return "medium"
    if weight >= 2:
        return "low"
    return "info"


def service_for(port: int, detected: str | None) -> str:
    if detected and detected in SERVICES:
        return detected
    return PORT_MAP.get(port, "unknown")


def grade_for(score: float, open_count: int) -> str:
    if open_count == 0:
        return "Minimal"
    if score < 20:
        return "Low"
    if score < 45:
        return "Moderate"
    if score < 70:
        return "High"
    return "Critical"


def analyze(ports: list[dict], scope: str) -> dict:
    """ports: list of open-port result dicts from the scanner."""
    findings: list[dict] = []
    seen_sigs: set[tuple] = set()

    def add(port, wid, title, weight, detail, fix, category):
        findings.append(dict(id=f"{wid}:{port}", port=port, severity=sev_for(weight), title=title,
                             weight=round(weight, 2), detail=detail, remediation=fix, category=category))

    for p in ports:
        port = p["port"]
        key = service_for(port, p.get("service"))
        svc = SERVICES[key]
        p["service"] = key
        p["label"] = svc["label"]
        base = svc["weight"]
        title = f"{svc['label']} exposed on port {port}"
        if key == "unknown":
            title = f"Unrecognised service listening on port {port}"
        # TLS-wrapped services lose the cleartext penalty.
        tls = p.get("tls") or {}
        add(port, "exposed", title, base, svc["why"], svc["fix"], svc["category"])
        if svc["clear"] and not tls:
            add(port, "cleartext", f"Cleartext protocol on port {port}", svc["clear"],
                f"{svc['label']} traffic and credentials are not encrypted.", "Enable TLS or tunnel through SSH/VPN.", "Encryption")

        text = p.get("banner", "") or ""
        for rx, sid, t, w, d, f in BANNER_SIGNATURES:
            if sid and re.search(rx, text, re.I):
                sig = (port, sid)
                if sig not in seen_sigs:
                    seen_sigs.add(sig)
                    add(port, sid, f"{t} on port {port}", w, d, f, "Vulnerable software")
        if _VERSION_DISCLOSURE.search(text) and not any(s[0] == port for s in seen_sigs):
            fw = FLAG_FINDINGS["http_version_disclosure"]
            add(port, "versiondisc", f"{fw[1]} (port {port})", fw[0], fw[2], fw[3], "Information disclosure")

        for flag in p.get("flags", []):
            if flag in FLAG_FINDINGS:
                w, t, d, f = FLAG_FINDINGS[flag]
                add(port, flag, f"{t} (port {port})", w, d, f, "Misconfiguration" if not flag.startswith("tls") else "Encryption")

    n = len(ports)
    if n > 10:
        w = min(5.0, (n - 10) * 0.5)
        findings.append(dict(id="surface:0", port=None, severity=sev_for(w), title=f"Large attack surface: {n} open ports",
                             weight=round(w, 2), detail="Every extra listener is another thing to patch and monitor.",
                             remediation="Close or firewall everything that isn't strictly required.", category="Attack surface"))

    findings.sort(key=lambda f: (-f["weight"], f["port"] or 0))
    raw = sum(f["weight"] for f in findings)
    mult = SCOPE_MULTIPLIER.get(scope, 1.0)
    adjusted = raw * mult
    score = round(100 * (1 - math.exp(-adjusted / 30)), 1) if n else 0.0

    cats: dict[str, float] = {}
    for f in findings:
        cats[f["category"]] = round(cats.get(f["category"], 0) + f["weight"] * mult, 2)
    sev_counts = {s: 0 for s in SEVERITIES}
    for f in findings:
        sev_counts[f["severity"]] += 1

    return dict(score=score, grade=grade_for(score, n), raw_weight=round(raw, 2), scope=scope,
                scope_multiplier=mult, findings=findings, categories=cats, severity_counts=sev_counts,
                top_actions=[dict(title=f["title"], fix=f["remediation"], severity=f["severity"]) for f in findings[:3]])
