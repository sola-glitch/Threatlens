# ThreatLens

Flask-based TCP port scanner with weighted risk scoring. Full-connect scans (no root), banner grabbing,
service fingerprinting independent of port number, TLS inspection (version, expiry, self-signed),
safe read-only probes (Redis PING, memcached version, Docker /version, Elasticsearch /), scan history,
diff against the previous scan, JSON/CSV export.

Docs: `docs/ALGORITHM.md` (design and pseudocode), `docs/USER_GUIDE.md`.

## Run
    pip install -r requirements.txt
    python app.py                 # http://127.0.0.1:5000
    python demo_services.py       # optional: fake weak services to scan (ports 2121,2222,6379,8080,8443,4444)
    python -m pytest tests

## Risk model (risk.py)
Each open port yields findings with weights 0-12: service exposure (e.g. Telnet 9, RDP 8, SSH 3), cleartext
penalty, vulnerable-banner signatures (vsftpd 2.3.4, old OpenSSH/Apache/IIS/PHP...), misconfig flags
(unauthenticated Redis +10, Docker API +5, expired cert +4...), and an attack-surface penalty above 10 ports.
Sum x scope multiplier (loopback 0.6, private 0.85, public 1.0), then score = 100*(1-exp(-x/30)).
Grades: Minimal (0 open), Low <20, Moderate <45, High <70, Critical.

## Safety
Binds 127.0.0.1; one host per scan (no CIDR); loopback/private only unless THREATLENS_ALLOW_PUBLIC=1;
mandatory authorisation checkbox; JSON-only POST (blocks cross-site triggering); max ports/threads capped;
all banner text rendered via textContent; CSV export neutralises formula injection.
Only scan systems you own or have written permission to test.

Env: THREATLENS_HOST, THREATLENS_PORT, THREATLENS_DB, THREATLENS_MAX_PORTS, THREATLENS_ALLOW_PUBLIC.
