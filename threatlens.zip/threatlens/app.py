"""ThreatLens: Flask web app around the scanner + risk model.

Safety defaults:
  * binds to 127.0.0.1
  * scans one host at a time (no CIDR sweeps)
  * loopback + private ranges only, unless THREATLENS_ALLOW_PUBLIC=1
  * every scan needs an explicit "I am authorised" confirmation
  * JSON-only POST (Content-Type: application/json) so other websites can't
    trigger scans from a victim's browser (the browser's CORS preflight blocks it)
"""
from __future__ import annotations

import csv
import io
import ipaddress
import json
import os
import socket
import sqlite3
import threading
import time
import uuid
from pathlib import Path

from flask import Flask, Response, jsonify, request, send_from_directory

import risk
import scanner

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("THREATLENS_DB", BASE / "threatlens.db"))
ALLOW_PUBLIC = os.environ.get("THREATLENS_ALLOW_PUBLIC") == "1"
MAX_PORTS = int(os.environ.get("THREATLENS_MAX_PORTS", "5000"))
MAX_ACTIVE = 3

app = Flask(__name__, static_folder=str(BASE / "static"), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024


# --------------------------------------------------------------------------- persistence
def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("""CREATE TABLE IF NOT EXISTS scans (
        id TEXT PRIMARY KEY, ip TEXT, target TEXT, started REAL, status TEXT, data TEXT)""")
    return con


def save_scan(d: dict):
    with db() as con:
        con.execute("INSERT OR REPLACE INTO scans VALUES (?,?,?,?,?,?)",
                    (d["id"], d["ip"], d["target"], d["started"], d["status"], json.dumps(d)))


def load_scan(sid: str):
    with db() as con:
        row = con.execute("SELECT data FROM scans WHERE id=?", (sid,)).fetchone()
    return json.loads(row["data"]) if row else None


def list_scans(limit=30):
    with db() as con:
        rows = con.execute("SELECT data FROM scans ORDER BY started DESC LIMIT ?", (limit,)).fetchall()
    out = []
    for r in rows:
        d = json.loads(r["data"])
        a = d.get("analysis") or {}
        out.append(dict(id=d["id"], target=d["target"], ip=d["ip"], started=d["started"], status=d["status"],
                        score=a.get("score"), grade=a.get("grade"), open_count=d.get("open_count", 0)))
    return out


def previous_scan(ip: str, before: float):
    with db() as con:
        row = con.execute("SELECT data FROM scans WHERE ip=? AND status='done' AND started<? ORDER BY started DESC LIMIT 1",
                          (ip, before)).fetchone()
    return json.loads(row["data"]) if row else None


# --------------------------------------------------------------------------- target validation
class TargetError(ValueError):
    pass


def resolve_target(raw: str):
    raw = (raw or "").strip()
    if not raw or len(raw) > 253 or any(c in raw for c in "/ \t\n\\?#@") or "://" in raw:
        raise TargetError("Enter a single hostname or IP address (no URLs, ranges or CIDR blocks).")
    try:
        infos = socket.getaddrinfo(raw, None, type=socket.SOCK_STREAM)
    except socket.gaierror:
        raise TargetError(f"Could not resolve '{raw}'.")
    family, _, _, _, sockaddr = infos[0]
    ip_str = sockaddr[0].split("%")[0]
    ip = ipaddress.ip_address(ip_str)
    if ip.is_unspecified or ip.is_multicast or ip.is_reserved:
        raise TargetError("That address is not a valid scan target.")
    if ip.is_loopback:
        scope = "loopback"
    elif ip.is_private or ip.is_link_local:
        scope = "private"
    else:
        scope = "public"
    if scope == "public" and not ALLOW_PUBLIC:
        raise TargetError("Public addresses are disabled. ThreatLens only scans loopback and private "
                          "ranges by default. Set THREATLENS_ALLOW_PUBLIC=1 to enable scanning hosts you own.")
    return ip_str, family, scope


# --------------------------------------------------------------------------- jobs
JOBS: dict[str, "Job"] = {}
JOBS_LOCK = threading.Lock()


class Job:
    def __init__(self, target, ip, family, scope, ports, timeout, workers):
        self.id = uuid.uuid4().hex[:12]
        self.target, self.ip, self.family, self.scope = target, ip, family, scope
        self.ports, self.timeout, self.workers = ports, timeout, workers
        self.status = "queued"
        self.done = 0
        self.open: list[dict] = []
        self.started = time.time()
        self.finished = None
        self.error = None
        self.analysis = None
        self.diff = None
        self.counts = {"closed": 0, "filtered": 0}
        self.cancel = threading.Event()

    def to_dict(self):
        ports_open = sorted(self.open, key=lambda r: r["port"])
        d = dict(id=self.id, target=self.target, ip=self.ip, scope=self.scope, status=self.status,
                 started=self.started, finished=self.finished, error=self.error,
                 progress=dict(done=self.done, total=len(self.ports)), open_count=len(ports_open),
                 closed=self.counts["closed"], filtered=self.counts["filtered"],
                 options=dict(timeout=self.timeout, workers=self.workers, total_ports=len(self.ports)),
                 results=ports_open, analysis=self.analysis, diff=self.diff)
        if self.finished:
            d["duration"] = round(self.finished - self.started, 2)
        return d

    def run(self):
        self.status = "running"
        try:
            out = scanner.run_scan(
                self.ip, self.family, self.ports, self.timeout, self.workers, self.cancel,
                on_progress=lambda done, total: setattr(self, "done", done),
                on_open=lambda r: self.open.append(r))
            self.counts = {"closed": out["closed"], "filtered": out["filtered"]}
            self.open = out["open"]
            self.analysis = risk.analyze(self.open, self.scope)
            final = "cancelled" if out["cancelled"] else "done"
        except Exception as e:  # pragma: no cover
            final, self.error = "error", str(e)
        self.finished = time.time()
        # Attach the diff and persist *before* publishing the final status, so a poller
        # that sees "done" always gets the complete record.
        if final == "done":
            self.diff = build_diff(self.to_dict())
        self.status = final
        save_scan(self.to_dict())


def build_diff(cur: dict):
    prev = previous_scan(cur["ip"], cur["started"])
    if not prev:
        return None
    now = {r["port"] for r in cur["results"]}
    then = {r["port"] for r in prev["results"]}
    ps, cs = (prev.get("analysis") or {}).get("score", 0), (cur.get("analysis") or {}).get("score", 0)
    return dict(previous_id=prev["id"], previous_started=prev["started"], newly_open=sorted(now - then),
                newly_closed=sorted(then - now), score_delta=round(cs - ps, 1),
                port_set_changed=bool(now ^ then))


# --------------------------------------------------------------------------- routes
@app.after_request
def headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'"
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/api/config")
def config():
    return jsonify(allow_public=ALLOW_PUBLIC, max_ports=MAX_PORTS, common_ports=len(scanner.COMMON_PORTS))


@app.post("/api/scans")
def start_scan():
    if not request.is_json:
        return jsonify(error="Content-Type must be application/json"), 415
    body = request.get_json(silent=True) or {}
    if body.get("authorized") is not True:
        return jsonify(error="You must confirm you are authorised to scan this target."), 400
    try:
        ip, family, scope = resolve_target(body.get("target"))
        spec = body.get("ports", "common")
        ports = scanner.parse_ports(spec if isinstance(spec, str) else "", MAX_PORTS)
        if len(ports) > MAX_PORTS:
            raise ValueError(f"Too many ports (limit {MAX_PORTS})")
        timeout = min(max(float(body.get("timeout", 0.8)), 0.1), 5.0)
        workers = min(max(int(body.get("workers", 100)), 1), 300)
    except TargetError as e:
        return jsonify(error=str(e)), 400
    except (ValueError, TypeError) as e:
        return jsonify(error=str(e)), 400

    with JOBS_LOCK:
        active = sum(1 for j in JOBS.values() if j.status in ("queued", "running"))
        if active >= MAX_ACTIVE:
            return jsonify(error="Too many scans running. Wait for one to finish."), 429
        job = Job(str(body["target"]).strip(), ip, family, scope, ports, timeout, workers)
        JOBS[job.id] = job
    threading.Thread(target=job.run, daemon=True).start()
    return jsonify(job.to_dict()), 202


@app.get("/api/scans")
def history():
    return jsonify(list_scans())


@app.get("/api/scans/<sid>")
def get_scan(sid):
    job = JOBS.get(sid)
    if job:
        return jsonify(job.to_dict())
    d = load_scan(sid)
    return (jsonify(d), 200) if d else (jsonify(error="Not found"), 404)


@app.post("/api/scans/<sid>/cancel")
def cancel(sid):
    job = JOBS.get(sid)
    if not job:
        return jsonify(error="Not found or already finished"), 404
    job.cancel.set()
    return jsonify(ok=True)


@app.delete("/api/scans/<sid>")
def delete_scan(sid):
    job = JOBS.get(sid)
    if job and job.status in ("queued", "running"):
        return jsonify(error="Scan still running"), 409
    JOBS.pop(sid, None)
    with db() as con:
        con.execute("DELETE FROM scans WHERE id=?", (sid,))
    return jsonify(ok=True)


def _csv_safe(v):
    s = "" if v is None else str(v)
    return "'" + s if s[:1] in "=+-@\t\r" else s


@app.get("/api/scans/<sid>/export.<fmt>")
def export(sid, fmt):
    d = (JOBS[sid].to_dict() if sid in JOBS else None) or load_scan(sid)
    if not d:
        return jsonify(error="Not found"), 404
    if fmt == "json":
        return Response(json.dumps(d, indent=2), mimetype="application/json",
                        headers={"Content-Disposition": f"attachment; filename=threatlens-{sid}.json"})
    if fmt == "csv":
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["severity", "port", "title", "weight", "category", "detail", "remediation"])
        for f in (d.get("analysis") or {}).get("findings", []):
            w.writerow([_csv_safe(f[k]) for k in ("severity", "port", "title", "weight", "category", "detail", "remediation")])
        return Response(buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": f"attachment; filename=threatlens-{sid}.csv"})
    return jsonify(error="Unsupported format"), 400


if __name__ == "__main__":
    host = os.environ.get("THREATLENS_HOST", "127.0.0.1")
    port = int(os.environ.get("THREATLENS_PORT", "5000"))
    print(f"ThreatLens on http://{host}:{port}  (public targets {'ENABLED' if ALLOW_PUBLIC else 'disabled'})")
    app.run(host=host, port=port, threaded=True)
