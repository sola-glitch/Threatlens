"""End-to-end tests against real local sockets (fake vulnerable-looking services)."""
import json
import os
import socket
import sys
import threading
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ["THREATLENS_DB"] = str(Path(__file__).parent / "test.db")

import app as tl  # noqa: E402
import risk  # noqa: E402
import scanner  # noqa: E402


class FakeServer(threading.Thread):
    """Accepts connections; optionally greets first, optionally replies to the first request."""
    def __init__(self, greeting=b"", reply=None, port=0):
        super().__init__(daemon=True)
        self.sock = socket.socket()
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("127.0.0.1", port))
        self.sock.listen(16)
        self.port = self.sock.getsockname()[1]
        self.greeting, self.reply = greeting, reply
        self.start()

    def run(self):
        while True:
            try:
                c, _ = self.sock.accept()
            except OSError:
                return
            try:
                if self.greeting:
                    c.sendall(self.greeting)
                elif self.reply is not None:
                    c.settimeout(1)
                    c.recv(1024)
                    c.sendall(self.reply)
                else:
                    time.sleep(0.2)
            except OSError:
                pass
            finally:
                c.close()


@pytest.fixture(scope="module")
def servers():
    s = dict(
        ftp=FakeServer(greeting=b"220 (vsFTPd 2.3.4)\r\n"),
        ssh=FakeServer(greeting=b"SSH-2.0-OpenSSH_5.3\r\n"),
        redis=FakeServer(reply=b"+PONG\r\n", port=6379),  # PING probe is only sent on the real Redis port
        quiet=FakeServer(),
    )
    yield s
    for v in s.values():
        v.sock.close()


def test_parse_ports():
    assert scanner.parse_ports("22,80,8000-8002") == [22, 80, 8000, 8001, 8002]
    assert 6379 in scanner.parse_ports("common")
    for bad in ("0", "70000", "abc", "1-99999"):
        with pytest.raises(ValueError):
            scanner.parse_ports(bad)
    with pytest.raises(ValueError):
        scanner.parse_ports("1-6000", max_ports=5000)


def test_scan_finds_open_closed_and_fingerprints(servers):
    ports = [s.port for s in servers.values()]
    closed = socket.socket(); closed.bind(("127.0.0.1", 0)); cp = closed.getsockname()[1]; closed.close()
    out = scanner.run_scan("127.0.0.1", socket.AF_INET, ports + [cp], timeout=0.5, workers=20)
    by = {r["port"]: r for r in out["open"]}
    assert set(by) == set(ports) and out["closed"] == 1
    assert by[servers["ssh"].port]["service"] == "ssh"
    assert by[servers["ftp"].port]["service"] == "ftp"
    assert "redis_unauthenticated" in by[servers["redis"].port]["flags"]
    assert by[servers["quiet"].port]["banner"] == ""


def test_risk_scoring(servers):
    ports = [s.port for s in servers.values()]
    out = scanner.run_scan("127.0.0.1", socket.AF_INET, ports, timeout=0.5)
    a = risk.analyze(out["open"], "loopback")
    ids = {f["id"].split(":")[0] for f in a["findings"]}
    assert {"vsftpd-backdoor", "old-openssh", "redis_unauthenticated"} <= ids
    assert a["findings"][0]["severity"] in ("critical", "high")
    assert 0 < a["score"] <= 100
    pub = risk.analyze(scanner.run_scan("127.0.0.1", socket.AF_INET, ports, timeout=0.5)["open"], "public")
    assert pub["score"] > a["score"]  # scope multiplier works
    assert risk.analyze([], "public") == risk.analyze([], "public") and risk.analyze([], "public")["score"] == 0


def test_cancel():
    ev = threading.Event(); ev.set()
    out = scanner.run_scan("127.0.0.1", socket.AF_INET, list(range(1, 200)), cancel=ev)
    assert out["cancelled"] and not out["open"]


@pytest.fixture()
def client():
    tl.app.config["TESTING"] = True
    return tl.app.test_client()


def _wait(client, sid):
    for _ in range(100):
        d = client.get(f"/api/scans/{sid}").get_json()
        if d["status"] not in ("queued", "running"):
            return d
        time.sleep(0.1)
    raise AssertionError("scan did not finish")


def test_api_requires_authorization_and_json(client):
    assert client.post("/api/scans", data="x").status_code == 415
    r = client.post("/api/scans", json={"target": "127.0.0.1"})
    assert r.status_code == 400 and "authorised" in r.get_json()["error"]


@pytest.mark.parametrize("target", ["8.8.8.8", "http://127.0.0.1", "10.0.0.0/8", "0.0.0.0", "224.0.0.1", ""])
def test_api_rejects_bad_or_public_targets(client, target):
    r = client.post("/api/scans", json={"target": target, "authorized": True})
    assert r.status_code == 400


def test_api_full_flow_diff_and_export(client, servers):
    ports = ",".join(str(s.port) for s in servers.values())
    ids = []
    for _ in range(2):
        r = client.post("/api/scans", json={"target": "127.0.0.1", "ports": ports, "authorized": True, "timeout": 0.5})
        assert r.status_code == 202
        d = _wait(client, r.get_json()["id"])
        assert d["status"] == "done" and d["open_count"] == 4 and d["scope"] == "loopback"
        ids.append(d["id"])
        time.sleep(0.02)
    assert d["diff"]["previous_id"] == ids[0] and not d["diff"]["port_set_changed"]
    assert any(h["id"] == ids[1] for h in client.get("/api/scans").get_json())
    j = client.get(f"/api/scans/{ids[1]}/export.json")
    assert json.loads(j.data)["id"] == ids[1]
    csv_text = client.get(f"/api/scans/{ids[1]}/export.csv").data.decode()
    assert csv_text.startswith("severity,port,title")
    assert client.delete(f"/api/scans/{ids[0]}").status_code == 200
    assert client.get(f"/api/scans/{ids[0]}").status_code == 404


def test_csv_injection_guard():
    assert tl._csv_safe("=cmd()") == "'=cmd()" and tl._csv_safe("ok") == "ok"


def teardown_module(_):
    p = Path(os.environ["THREATLENS_DB"])
    if p.exists():
        p.unlink()
